﻿V 1.5.5

Support of tag attributes

V 1.5.6

Region and language related Excel bugs fixed  

V 1.5.7

bugs fixing